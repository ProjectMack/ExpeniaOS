﻿Public Class Discord
    Private Sub Discord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AxWebBrowser1.Navigate("Discord.gg")
    End Sub
End Class